import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-track-admin',
    templateUrl: './track-admin.component.html',
    styleUrls: ['./track-admin.component.css']
})
export class TrackAdminComponent implements OnInit {

    constructor() { }

    ngOnInit() {
    }

}

import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-racing-game',
    templateUrl: './racing-game.component.html',
    styleUrls: ['./racing-game.component.css']
})
export class RacingGameComponent implements OnInit {

    constructor() { }

    public ngOnInit() {
    }

}

import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'aapp-track-info',
    templateUrl: './track-info.component.html',
    styleUrls: ['./track-info.component.css']
})
export class TrackInfoComponent implements OnInit {

    constructor() { }

    ngOnInit() {
    }

}

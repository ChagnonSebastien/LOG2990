import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-racing-header',
    templateUrl: './racing-header.component.html',
    styleUrls: ['./racing-header.component.css']
})
export class RacingHeaderComponent implements OnInit {

    constructor() { }

    public ngOnInit() {
    }

}

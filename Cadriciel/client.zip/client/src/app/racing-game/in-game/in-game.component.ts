import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-in-game',
    templateUrl: './in-game.component.html',
    styleUrls: ['./in-game.component.css']
})
export class InGameComponent implements OnInit {

    constructor() { }

    ngOnInit() {
    }

}
